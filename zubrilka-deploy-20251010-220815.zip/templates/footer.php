        <hr>

        <!-- Footer -->
        <footer>
            <div class="row">
                <div class="col-md-12 text-center" style="padding-bottom: 20px;">
                    <p style="margin: 0; font-weight: 500;">© 2025 Зубрилка</p>
                </div>
            </div>
        </footer>

    </div>
    <!-- /.container -->
</html>
