# 🔐 Учётные данные администратора

## Доступ к админ-панели

**URL**: http://localhost:8080/admin/

### HTTP Basic Auth

- **Логин**: `admin`
- **Пароль**: `Asma2016a`

## Как изменить пароль

1. Войдите в контейнер:
   ```bash
   docker exec -it poems-web bash
   ```

2. Создайте новый пароль:
   ```bash
   htpasswd -c /var/www/html/admin/.htpasswd admin
   ```

3. Введите новый пароль дважды

## Как добавить нового пользователя

```bash
docker exec -it poems-web htpasswd -b /var/www/html/admin/.htpasswd username password
```

## Безопасность

⚠️ **Важно**: 
- Этот файл не должен попадать в публичный репозиторий
- Измените пароль при развёртывании на продакшене
- Используйте сложные пароли

## Отключение авторизации (для разработки)

Переименуйте или удалите файл:
```bash
mv admin/.htaccess admin/.htaccess.disabled
```

Для включения обратно:
```bash
mv admin/.htaccess.disabled admin/.htaccess
```
